import{w as t}from"./index-1dc67d24.js";function h({theadDatas:r}){return t.jsx("thead",{children:t.jsx("tr",{children:r.map((e,s)=>t.jsx("th",{children:e},s))})})}export{h as T};
