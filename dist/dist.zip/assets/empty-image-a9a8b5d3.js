const e="/assets/empty-image-8ae3bbad.png";export{e};
